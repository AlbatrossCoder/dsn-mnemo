/**
 * Bounded "seen message id" set, so a reconnect replay cannot double-process.
 */
export declare function createDedupe(max?: number): (id: string) => boolean;
