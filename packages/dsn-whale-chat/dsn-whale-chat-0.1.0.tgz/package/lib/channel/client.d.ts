import { type Connect } from './transport.js';
import type { ChatMessage } from './types.js';
export interface ClientOptions {
    /** OneBot 11 WS endpoint, e.g. `ws://127.0.0.1:3001`. */
    readonly url: string;
    /** Optional access token; appended as `?access_token=`. */
    readonly token?: string;
    /** Transport seam; defaults to the real Node `WebSocket`. */
    readonly connect?: Connect;
    readonly onMessage: (message: ChatMessage) => void;
    readonly onError?: (error: unknown) => void;
    /** Backoff base delay, default 1000ms. */
    readonly reconnectBaseMs?: number;
    /** Backoff cap, default 30000ms. */
    readonly reconnectMaxMs?: number;
}
export declare class OneBotClient {
    private readonly options;
    private readonly connect;
    private readonly isNewMessage;
    private connection;
    private open;
    private stopped;
    private attempt;
    private timer;
    private echo;
    constructor(options: ClientOptions);
    get connected(): boolean;
    start(): void;
    stop(): void;
    /** Send a raw OneBot action. Throws when not connected. */
    send(action: string, params: Record<string, unknown>): void;
    sendPrivate(userId: string, text: string): void;
    sendGroup(groupId: string, text: string): void;
    private openSocket;
    private tokenizedUrl;
    private handle;
    private handleClose;
}
