/**
 * OneBot 11 event parsing: turn a raw WS frame into a normalized {@link ChatMessage}.
 *
 * Only `post_type === 'message'` events are conversation; everything else
 * (heartbeats, lifecycle, notices) is ignored here.
 */
import type { ChatMessage } from './types.js';
/** Parse one frame; returns `null` when it is not a routable message event. */
export declare function parseEvent(raw: string): ChatMessage | null;
