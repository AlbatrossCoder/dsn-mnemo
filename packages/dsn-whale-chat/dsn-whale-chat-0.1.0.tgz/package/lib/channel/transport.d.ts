/**
 * WS transport seam.
 *
 * The client takes a {@link Connect} function so tests can drive a fake socket
 * without a real OneBot server. The default factory uses Node's global
 * `WebSocket` (Node 22+), passing the token as `?access_token=`.
 */
export interface Connection {
    send(data: string): void;
    close(): void;
}
export interface ConnectHandlers {
    onOpen(): void;
    onMessage(data: string): void;
    onClose(): void;
    onError?(error: unknown): void;
}
export type Connect = (url: string, handlers: ConnectHandlers) => Connection;
/** Real transport: Node's global WebSocket, token via `access_token` query. */
export declare const webSocketConnect: Connect;
