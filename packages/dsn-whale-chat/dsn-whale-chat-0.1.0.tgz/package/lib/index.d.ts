import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Cordis plugin name; must stay stable so profile entries can target it. */
export declare const name = "dsn-whale-chat";
/** Services required before `apply` runs. */
export declare const inject: string[];
/** User-facing configuration (mirrors docs/chat-plugin.md §6). */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    wsUrl: z<string, string, "defined">;
    accessToken: z<string, string, "defined">;
    statePath: z<string, string, "defined">;
    provider: z<string, string, "defined">;
    model: z<string, string, "defined">;
    persona: z<Schemastery.ObjectS<NoInfer<{
        active: z<string, string, "defined">;
        addressUser: z<string, string, "defined">;
        custom: z<string, string, "defined">;
        aliases: z<string[], string[], "defined">;
        disliked: z<string[], string[], "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        active: z<string, string, "defined">;
        addressUser: z<string, string, "defined">;
        custom: z<string, string, "defined">;
        aliases: z<string[], string[], "defined">;
        disliked: z<string[], string[], "defined">;
    }>>, "plain">;
    /** Extra personas appended on top of the built-ins (same id overrides). */
    personas: z<any[], any[], "defined">;
    toggles: z<Schemastery.ObjectS<NoInfer<{
        mischief: z<boolean, boolean, "defined">;
        queen: z<boolean, boolean, "defined">;
        kaomoji: z<boolean, boolean, "defined">;
        troll: z<boolean, boolean, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        mischief: z<boolean, boolean, "defined">;
        queen: z<boolean, boolean, "defined">;
        kaomoji: z<boolean, boolean, "defined">;
        troll: z<boolean, boolean, "defined">;
    }>>, "plain">;
    trigger: z<Schemastery.ObjectS<NoInfer<{
        /** `at` | `all` | `keyword`. */
        group: z<string, string, "defined">;
        keywords: z<string[], string[], "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        /** `at` | `all` | `keyword`. */
        group: z<string, string, "defined">;
        keywords: z<string[], string[], "defined">;
    }>>, "plain">;
    rate: z<Schemastery.ObjectS<NoInfer<{
        debounceMs: z<number, number, "defined">;
        batchSize: z<number, number, "defined">;
        cooldownMs: z<number, number, "defined">;
        maxPerMinute: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        debounceMs: z<number, number, "defined">;
        batchSize: z<number, number, "defined">;
        cooldownMs: z<number, number, "defined">;
        maxPerMinute: z<number, number, "defined">;
    }>>, "plain">;
    groupRate: z<Schemastery.ObjectS<NoInfer<{
        debounceMs: z<number, number, "defined">;
        batchSize: z<number, number, "defined">;
        cooldownMs: z<number, number, "defined">;
        maxPerMinute: z<number, number, "defined">;
        maxPerHour: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        debounceMs: z<number, number, "defined">;
        batchSize: z<number, number, "defined">;
        cooldownMs: z<number, number, "defined">;
        maxPerMinute: z<number, number, "defined">;
        maxPerHour: z<number, number, "defined">;
    }>>, "plain">;
    proactive: z<Schemastery.ObjectS<NoInfer<{
        private: z<Schemastery.ObjectS<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, "plain">;
        group: z<Schemastery.ObjectS<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, "plain">;
    }>>, Schemastery.ObjectT<NoInfer<{
        private: z<Schemastery.ObjectS<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, "plain">;
        group: z<Schemastery.ObjectS<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, "plain">;
    }>>, "plain">;
    randomInterject: z<Schemastery.ObjectS<NoInfer<{
        enabled: z<boolean, boolean, "defined">;
        probability: z<number, number, "defined">;
        minMessagesBetween: z<number, number, "defined">;
        maxPerHour: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        enabled: z<boolean, boolean, "defined">;
        probability: z<number, number, "defined">;
        minMessagesBetween: z<number, number, "defined">;
        maxPerHour: z<number, number, "defined">;
    }>>, "plain">;
    schedule: z<Schemastery.ObjectS<NoInfer<{
        quietHours: z<number[], number[], "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        quietHours: z<number[], number[], "defined">;
    }>>, "plain">;
}>>, Schemastery.ObjectT<NoInfer<{
    wsUrl: z<string, string, "defined">;
    accessToken: z<string, string, "defined">;
    statePath: z<string, string, "defined">;
    provider: z<string, string, "defined">;
    model: z<string, string, "defined">;
    persona: z<Schemastery.ObjectS<NoInfer<{
        active: z<string, string, "defined">;
        addressUser: z<string, string, "defined">;
        custom: z<string, string, "defined">;
        aliases: z<string[], string[], "defined">;
        disliked: z<string[], string[], "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        active: z<string, string, "defined">;
        addressUser: z<string, string, "defined">;
        custom: z<string, string, "defined">;
        aliases: z<string[], string[], "defined">;
        disliked: z<string[], string[], "defined">;
    }>>, "plain">;
    /** Extra personas appended on top of the built-ins (same id overrides). */
    personas: z<any[], any[], "defined">;
    toggles: z<Schemastery.ObjectS<NoInfer<{
        mischief: z<boolean, boolean, "defined">;
        queen: z<boolean, boolean, "defined">;
        kaomoji: z<boolean, boolean, "defined">;
        troll: z<boolean, boolean, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        mischief: z<boolean, boolean, "defined">;
        queen: z<boolean, boolean, "defined">;
        kaomoji: z<boolean, boolean, "defined">;
        troll: z<boolean, boolean, "defined">;
    }>>, "plain">;
    trigger: z<Schemastery.ObjectS<NoInfer<{
        /** `at` | `all` | `keyword`. */
        group: z<string, string, "defined">;
        keywords: z<string[], string[], "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        /** `at` | `all` | `keyword`. */
        group: z<string, string, "defined">;
        keywords: z<string[], string[], "defined">;
    }>>, "plain">;
    rate: z<Schemastery.ObjectS<NoInfer<{
        debounceMs: z<number, number, "defined">;
        batchSize: z<number, number, "defined">;
        cooldownMs: z<number, number, "defined">;
        maxPerMinute: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        debounceMs: z<number, number, "defined">;
        batchSize: z<number, number, "defined">;
        cooldownMs: z<number, number, "defined">;
        maxPerMinute: z<number, number, "defined">;
    }>>, "plain">;
    groupRate: z<Schemastery.ObjectS<NoInfer<{
        debounceMs: z<number, number, "defined">;
        batchSize: z<number, number, "defined">;
        cooldownMs: z<number, number, "defined">;
        maxPerMinute: z<number, number, "defined">;
        maxPerHour: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        debounceMs: z<number, number, "defined">;
        batchSize: z<number, number, "defined">;
        cooldownMs: z<number, number, "defined">;
        maxPerMinute: z<number, number, "defined">;
        maxPerHour: z<number, number, "defined">;
    }>>, "plain">;
    proactive: z<Schemastery.ObjectS<NoInfer<{
        private: z<Schemastery.ObjectS<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, "plain">;
        group: z<Schemastery.ObjectS<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, "plain">;
    }>>, Schemastery.ObjectT<NoInfer<{
        private: z<Schemastery.ObjectS<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, "plain">;
        group: z<Schemastery.ObjectS<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            enabled: z<boolean, boolean, "defined">;
            idleMinutes: z<number, number, "defined">;
            maxPerDay: z<number, number, "defined">;
        }>>, "plain">;
    }>>, "plain">;
    randomInterject: z<Schemastery.ObjectS<NoInfer<{
        enabled: z<boolean, boolean, "defined">;
        probability: z<number, number, "defined">;
        minMessagesBetween: z<number, number, "defined">;
        maxPerHour: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        enabled: z<boolean, boolean, "defined">;
        probability: z<number, number, "defined">;
        minMessagesBetween: z<number, number, "defined">;
        maxPerHour: z<number, number, "defined">;
    }>>, "plain">;
    schedule: z<Schemastery.ObjectS<NoInfer<{
        quietHours: z<number[], number[], "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        quietHours: z<number[], number[], "defined">;
    }>>, "plain">;
}>>, "plain">;
export type WhaleChatConfig = Schemastery.TypeT<typeof Config>;
export declare function apply(ctx: Context, config: WhaleChatConfig): void;
