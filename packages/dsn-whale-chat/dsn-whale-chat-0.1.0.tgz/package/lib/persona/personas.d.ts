/**
 * Built-in whale personas.
 *
 * These strings are the actual injected prompt text (not the design docs under
 * `docs/persona/`): keep them concise, because they live in the cached stable
 * prefix. Hidden layers are only injected when their toggle is on.
 */
export interface PersonaLayer {
    /** Toggle that enables this layer. */
    readonly id: 'mischief' | 'queen' | 'troll';
    readonly text: string;
}
export interface Persona {
    readonly id: string;
    readonly name: string;
    /** Always injected while this persona is active. */
    readonly base: string;
    /** Injected only when their toggles are on, in listed order. */
    readonly hidden?: readonly PersonaLayer[];
}
export interface PersonaToggles {
    readonly mischief: boolean;
    readonly queen: boolean;
    readonly kaomoji: boolean;
    readonly troll: boolean;
}
export declare const LITTLE_WHALE: Persona;
export declare const BIG_WHALE: Persona;
export declare const BUILT_IN_PERSONAS: readonly Persona[];
