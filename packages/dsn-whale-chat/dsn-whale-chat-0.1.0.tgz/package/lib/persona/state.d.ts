import type { PersonaToggles } from './personas.js';
export interface PersonaState {
    activeId: string;
    name: string;
    addressUser: string;
    custom: string;
    toggles: PersonaToggles;
}
export interface StateStore {
    get(): PersonaState;
    update(patch: Partial<Omit<PersonaState, 'toggles'>> & {
        toggles?: Partial<PersonaToggles>;
    }): PersonaState;
    reset(): PersonaState;
}
export declare function createStateStore(path: string, defaults: PersonaState): StateStore;
