import type { Persona, PersonaToggles } from './personas.js';
export interface AssembleOptions {
    /** Replaces the persona's default address when the user set one. */
    readonly addressUser?: string;
    /** User-appended setting, injected last (highest priority). */
    readonly custom?: string;
    readonly toggles: PersonaToggles;
}
/**
 * Assemble the injected persona text.
 *
 * Order: base → each enabled hidden layer (in listed order) → address override
 * → no-kaomoji rule → user custom. A disabled hidden layer is omitted entirely,
 * so it never reaches the model (saves tokens, leaks nothing).
 */
export declare function assemblePersona(persona: Persona, options: AssembleOptions): string;
