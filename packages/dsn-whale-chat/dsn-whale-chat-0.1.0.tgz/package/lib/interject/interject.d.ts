/**
 * Random interjection gate for group chatter.
 *
 * Experimental and off by default: on every non-addressed group message there
 * is a small probability of joining in, but only after `minMessagesBetween`
 * and at most `maxPerHour`. Risk-heavy features stay conservative.
 */
export interface InterjectPolicy {
    readonly enabled: boolean;
    readonly probability: number;
    readonly minMessagesBetween: number;
    readonly maxPerHour: number;
}
export interface InterjectOptions {
    readonly now?: () => number;
    readonly random?: () => number;
}
/** Build a gate: call it for each non-addressed group message; `true` = join in. */
export declare function createInterjectGate(policy: InterjectPolicy, options?: InterjectOptions): () => boolean;
