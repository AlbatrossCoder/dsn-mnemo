/**
 * Idle proactive speech: after a conversation goes quiet for a while, wake the
 * agent once with a "you may speak, or stay silent" nudge.
 *
 * Rate-safe by construction: at most `maxPerDay` fires per conversation, and
 * nothing fires during quiet hours.
 */
import { type Scheduler } from '../util/scheduler.js';
export interface ProactivePolicy {
    readonly idleMs: number;
    readonly maxPerDay: number;
    /** Local-time `[startHour, endHour)` during which nothing fires. */
    readonly quietHours: readonly [number, number];
}
export interface ProactiveOptions {
    readonly policy: ProactivePolicy;
    readonly onFire: (key: string) => void;
    readonly scheduler?: Scheduler;
    readonly now?: () => number;
}
export declare class ProactiveScheduler {
    private readonly options;
    private readonly timers;
    private readonly days;
    private readonly scheduler;
    private readonly now;
    constructor(options: ProactiveOptions);
    /** Reset the idle timer for one conversation (call on every inbound message). */
    noteActivity(key: string): void;
    cancel(key: string): void;
    cancelAll(): void;
    private fire;
    private admit;
    private isQuiet;
}
