import type { ChatMessage } from '../channel/types.js';
/**
 * Declare the QQ identity a channel message carries. `MessageSourceMap` is
 * merge-extensible (see `@deepseek-ai/dsh-llm/message`), so this adds the `qq`
 * producer without touching the harness.
 */
declare module '@deepseek-ai/dsh-llm/message' {
    interface MessageSourceMap {
        qq: {
            readonly kind: 'qq';
            readonly userId: string;
            readonly groupId?: string;
            readonly mentioned?: boolean;
        };
        /** A synthetic "you may speak" nudge; never a chat-log message. */
        'qq-proactive': {
            readonly kind: 'qq-proactive';
            readonly userId: string;
            readonly groupId?: string;
        };
    }
}
/** One conversation = one agent/session; the key names that conversation. */
export declare function conversationKey(message: ChatMessage): string;
/** Build the identified user message the agent will receive. */
export declare function toUserMessage(message: ChatMessage): {
    content: {
        type: "text";
        text: string;
    }[];
    source: {
        kind: "qq";
        userId: string;
        groupId?: string | undefined;
        mentioned: boolean;
    };
} & Pick<import("@deepseek-ai/dsh-llm/message").UserMessage, "id" | "role">;
export declare function toProactiveMessage(message: ChatMessage): {
    content: {
        type: "text";
        text: string;
    }[];
    source: {
        kind: "qq-proactive";
        userId: string;
        groupId?: string | undefined;
    };
} & Pick<import("@deepseek-ai/dsh-llm/message").UserMessage, "id" | "role">;
export declare function toInterjectMessage(message: ChatMessage, text: string): {
    content: {
        type: "text";
        text: string;
    }[];
    source: {
        kind: "qq-proactive";
        userId: string;
        groupId?: string | undefined;
    };
} & Pick<import("@deepseek-ai/dsh-llm/message").UserMessage, "id" | "role">;
