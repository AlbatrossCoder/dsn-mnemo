import type { Context } from '@deepseek-ai/cordis';
import type { ChatMessage } from '../channel/types.js';
export interface BridgeOptions {
    readonly ctx: Context;
    /** Deliver the assistant's reply back to QQ. */
    readonly reply: (target: ChatMessage, text: string) => void;
    readonly onError?: (error: unknown) => void;
    readonly provider?: string;
    readonly model?: string;
}
/**
 * Route inbound QQ messages into one DSH agent per conversation, and send the
 * assistant's replies back out.
 *
 * Sessions are created with a per-process id, so a restart starts a fresh
 * session; cross-session memory is `dsn-mnemo`'s job, not this bridge's.
 */
export declare class ChatBridge {
    private readonly options;
    private readonly agents;
    private readonly conversations;
    constructor(options: BridgeOptions);
    receive(message: ChatMessage): Promise<void>;
    /** Wake the agent for an idle proactive turn; it may answer or stay silent. */
    proactive(target: ChatMessage): Promise<void>;
    /** Wake the agent to consider joining a group message it was not addressed in. */
    interject(target: ChatMessage, text: string): Promise<void>;
    private agentFor;
}
