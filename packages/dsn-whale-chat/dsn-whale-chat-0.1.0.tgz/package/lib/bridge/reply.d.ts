import type { ContentBlock } from '@deepseek-ai/dsh-llm';
/** Concatenate the visible text blocks of one assistant message. */
export declare function assistantText(content: readonly ContentBlock[]): string;
