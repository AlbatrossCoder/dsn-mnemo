import type { Persona } from '../persona/personas.js';
import type { StateStore } from '../persona/state.js';
export declare function createPersonaSetTool(store: StateStore): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function createPersonaSwitchTool(store: StateStore, personas: readonly Persona[]): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function createPersonaToggleTool(store: StateStore): import("@deepseek-ai/dsh-tools").ToolDefinition;
