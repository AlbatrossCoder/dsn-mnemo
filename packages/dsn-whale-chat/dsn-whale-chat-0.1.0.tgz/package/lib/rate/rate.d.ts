/**
 * Chat rate control: debounce bursts, merge them into one turn, and enforce
 * cooldown / per-minute / per-hour limits per conversation.
 *
 * Pure state machine with injectable clock and scheduler, so it is testable
 * without real timers.
 */
import { type Scheduler } from '../util/scheduler.js';
export interface RatePolicy {
    /** Wait this long after the last message before flushing. */
    readonly debounceMs: number;
    /** Flush early once this many messages accumulate; 0 disables early flush. */
    readonly batchSize: number;
    /** Minimum gap between two flushes. */
    readonly cooldownMs: number;
    readonly maxPerMinute: number;
    readonly maxPerHour: number;
}
export interface RateOptions {
    readonly policy: RatePolicy;
    /** Called with the merged texts when a batch is admitted. */
    readonly onFlush: (key: string, texts: readonly string[]) => void;
    readonly scheduler?: Scheduler;
    readonly now?: () => number;
}
export declare class RateController {
    private readonly options;
    private readonly pending;
    private readonly timers;
    private readonly lastFlushAt;
    private readonly minute;
    private readonly hour;
    private readonly scheduler;
    private readonly now;
    constructor(options: RateOptions);
    /** Accept one message; may flush immediately (batch) or arm the debounce. */
    offer(key: string, text: string): void;
    /** Forget one conversation's pending work and timer. */
    cancel(key: string): void;
    /** Forget every conversation's pending work and timer. */
    cancelAll(): void;
    private arm;
    private flush;
    private admit;
    private window;
    private clearTimer;
}
