/** Small text helpers shared by the chat routing. */
/** True when `text` contains any configured name/keyword (case-insensitive). */
export declare function matchesAny(text: string, needles: readonly string[]): boolean;
